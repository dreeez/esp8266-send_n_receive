Example code: 
Arduino IDE >> File >> Examples >> Examples for Custom Librarys >> Split String
