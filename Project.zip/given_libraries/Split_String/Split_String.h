#include <Arduino.h>
#ifndef Split_String_h
#define Split_String_h
class Split_String {
public:
	Split_String();
	String brakestring(String data, char Split_String, int index);
private:
};
#endif
